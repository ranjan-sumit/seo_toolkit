# Import libraries
import cupy as cp
import os
import torch
import concurrent.futures
import time
import json
import pandas as pd
import re
import numpy as np
import glob
from cucim import CuImage
from PIL import Image
from cucim.skimage import feature, exposure, morphology
from cucim.skimage.morphology import reconstruction
from cucim.skimage import filters
from cucim.skimage.color import rgb2gray
from cucim.skimage.measure import label, regionprops
from skimage.transform import hough_circle, hough_circle_peaks
from skimage.draw import disk
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from math import sqrt
import pandas as pd
from scipy import ndimage
import warnings

from matplotlib.collections import PatchCollection
from matplotlib.patches import Circle

warnings.filterwarnings('ignore')

# Function to invert image
def invert_image(image):
    image_cp = cp.asarray(image)  # Convert image to CuPy array
    return (image_cp - 1) * (-1)

def detect_circle_by_canny(image_bw, radius=395, n_peaks=20):
    # Ensure the image is a CuPy array and has the right dtype
    image_bw = cp.asarray(image_bw, dtype=cp.float32)

    # Apply Canny edge detection (GPU-accelerated)
    edges = feature.canny(image_bw, sigma=2)

    # Convert to NumPy array before calling skimage's hough_circle
    edges_np = cp.asnumpy(edges)

    # Hough Circle Transform (CPU-based)
    hough_res = hough_circle(edges_np, [radius])
    accums, cx, cy, radii = hough_circle_peaks(hough_res, [radius], total_num_peaks=n_peaks)

    # Convert cx, cy, and radii to CuPy arrays for GPU processing
    cx, cy, radii = cp.array(cx), cp.array(cy), cp.array(radii)

    label = cp.zeros_like(image_bw)
    ind = 1
    for center_y, center_x, radius in zip(cy, cx, radii):
        # Convert CuPy arrays to NumPy before passing to disk function
        circy, circx = disk((center_y.get(), center_x.get()), radius.get(), shape=image_bw.shape)
        # Convert result back to CuPy array
        circy, circx = cp.array(circy), cp.array(circx)
        label[circy, circx] = ind
        ind += 1

    return label.astype(int)

# Function to get radius from bounding box
def _get_radius(bbox):
    minr, minc, maxr, maxc = bbox
    r = cp.array([[maxr - minr], [maxc - minc]]).mean() / 2
    return r

# Function to convert bounding box to centroid
def _bbox_to_center(bbox):
    minr, minc, maxr, maxc = bbox
    c = int(cp.array([minc, maxc]).mean())
    r = int(cp.array([minr, maxr]).mean())
    return r, c

# Function to create circle label
def make_circle_label(bb_list, img_shape):
    # Convert the list of radii to a CuPy array before taking the median
    radius = cp.median(cp.array([_get_radius(i) for i in bb_list]))

    # Create the label array on the GPU
    label = cp.zeros(img_shape)

    id = 1
    for bb in bb_list:
        # get centroid
        r, c = _bbox_to_center(bb)

        # Convert r, c, and radius to NumPy arrays before passing to disk()
        rr, cc = disk((int(r), int(c)), int(radius.get()))

        # Convert rr and cc to CuPy arrays before assigning to label
        rr, cc = cp.array(rr), cp.array(cc)

        label[rr, cc] = id
        id += 1

    return label.astype(int)

# Function to crop circle from image
def crop_circle(image, shrinkage_ratio=0.95):
    image_cp = cp.asarray(image)  # Convert image to CuPy array
    x, y = image_cp.shape
    center = (int(x / 2), int(y / 2))
    diameter = min(center)

    threshold = (diameter * shrinkage_ratio) ** 2

    # Vectorized operation for cropping as a circle using CuPy
    X, Y = cp.ogrid[:x, :y]
    dist = (X - center[0])**2 + (Y - center[1])**2
    mask = dist < threshold

    return image_cp * mask  # Return CuPy array

def background_subtraction(image, sigma=1, verbose=True):
    # Convert image to a numpy array
    image_ = ndimage.gaussian_filter(cp.asnumpy(image), sigma)

    # Prepare seed and mask
    seed = image_ - 0.4
    mask = image_

    # Use cucim's reconstruction method
    seed_cp = cp.asarray(seed)
    mask_cp = cp.asarray(mask)
    dilated = reconstruction(seed_cp, mask_cp, method='dilation')

    # Convert back to numpy array for further processing
    result = cp.asnumpy(image_) - cp.asnumpy(dilated)
    result = cp.asarray(result)

    if verbose:
        plt.subplot(1, 4, 1)
        plt.imshow(cp.asnumpy(image))

        plt.subplot(1, 4, 2)
        plt.imshow(image_)

        plt.subplot(1, 4, 3)
        plt.imshow(cp.asnumpy(dilated))

        plt.subplot(1, 4, 4)
        plt.imshow(cp.asnumpy(result))
        plt.show()

    return result

# Function to search for blobs in image
def search_for_blobs(image, min_size=3, max_size=15, num_sigma=10, overlap=0.5, threshold=0.02):
    # blobs_log = feature.blob_log(image, max_sigma=max_size, min_sigma=min_size, num_sigma=num_sigma, overlap=overlap, threshold=threshold, log_scale=True)
    blobs_log = feature.blob_log(cp.asarray(image), max_sigma=max_size, min_sigma=min_size, num_sigma=num_sigma, overlap=overlap, threshold=threshold, log_scale=True)
    # blobs_log[:, 2] = blobs_log[:, 2] * sqrt(2)
    blobs_log_cp = cp.asarray(blobs_log)
    blobs_log_cp[:, 2] = blobs_log_cp[:, 2] * cp.sqrt(2)

    return blobs_log_cp

def _get_vmax(image_list):
    vmax = [cp.max(cp.asarray(image)) for image in image_list]  # Ensure each image is a CuPy array
    return max(vmax)  # Use Python's built-in max function to get the maximum value from the list

# Function to plot bounding boxes
def plot_bboxs(bbox_list, ax, args={"edgecolor": 'white', "linewidth": 2, "alpha": 0.5}):
    for bb in bbox_list:
        minr, minc, maxr, maxc = bb
        rect = mpatches.Rectangle((minc, minr), maxc - minc, maxr - minr, fill=False, **args)
        ax.add_patch(rect)

# Function to plot text labels
def plot_texts(text_list, cordinate_list, ax, shift=[0, 0], fontdict={'color': 'white', 'weight': 'normal', 'size': 10}):
    for text, cordinate in zip(text_list, cordinate_list):
        plt.text(x=cordinate[1] + shift[0], y=cordinate[0] + shift[1], s=str(text), fontdict=fontdict)

# Optimized function to plot circles
def plot_circles(circle_list, ax, args={"color": "white", "linewidth": 1, "alpha": 0.5}):
    circles = [Circle((x, y), r, **args, fill=False) for y, x, r in circle_list]

    # Use PatchCollection to batch the plotting of circles
    p = PatchCollection(circles, match_original=True)
    ax.add_collection(p)

# Function for easy subplotting
def easy_sub_plot(image_list, col_num=3, title_list=None, args={}):
    for i, image in enumerate(image_list):
        k = (i % col_num + 1)
        plt.subplot(1, col_num, k)
        plt.imshow(cp.asnumpy(image), **args)
        plt.title(title_list[i])
        if (k == col_num) | (i == len(image_list)):
            plt.show()

# Class for colony counting and analysis
class Counter():

    def __init__(self, image_path=None, image_array=None, image_data=None, verbose=True):
        self.props = {}
        if image_path is not None:
            self.load_from_path(image_path, verbose=verbose)
        if image_array is not None:
            self.load_image(image_array, verbose=verbose)

    def load_from_path(self, image_path, verbose=True):
        # Load the image using appropriate method based on file type
        if image_path.lower().endswith(('.tif', '.tiff')):
            cu_image = CuImage(image_path)
            image = cp.asarray(cu_image.read_region())  # Get the image data as a CuPy array
        else:
            pil_image = Image.open(image_path)
            image = cp.array(pil_image)  # Convert to CuPy array

        # Handle images with 4 channels (RGBA)
        if image.shape[-1] == 4:
            image = image[:, :, :3]  # Drop the alpha channel

        self.load_image(image, verbose=verbose)

    def load_image(self, image_array, verbose=True):
        self.image_raw = image_array.copy()
        self.image_bw = rgb2gray(self.image_raw)  # Convert to grayscale using cucim
        self.image_inverted_bw = self.invert_image(self.image_bw)

        if verbose:
            plt.imshow(cp.asnumpy(self.image_raw))
            plt.show()

    def invert_image(self, image):
        image_cp = cp.asarray(image)  # Convert image to CuPy array
        return (image_cp - 1) * (-1)

    def detect_area_by_canny(self, n_samples=None, radius=395, n_peaks=20, verbose=True):
      if verbose:
          print("detecting sample area...")

      # 1. Segmentation
      bw = self.image_bw.copy()

      # detect circles by canny method
      labeled = detect_circle_by_canny(bw, radius=radius, n_peaks=n_peaks)

      self.labeled = labeled

      if verbose:
          plt.title("segmentation")
          plt.imshow(cp.asnumpy(labeled))
          plt.show()

      # 2. region props - Use cucim's regionprops directly on CuPy arrays
      props = regionprops(label_image=labeled, intensity_image=self.image_bw)

      # Extract properties directly into CuPy arrays
      bboxs = cp.array([prop.bbox for prop in props])
      areas = cp.array([prop.area for prop in props])
      cordinates = cp.array([prop.centroid for prop in props])
      eccentricities = cp.array([prop.eccentricity for prop in props])
      intensity = cp.array([prop.intensity_image.mean() for prop in props])

      # 3. filter object
      selected = (areas >= cp.percentile(areas, 90)) & (eccentricities < 0.3)

      # update labels
      labeled = make_circle_label(bb_list=bboxs[selected], img_shape=self.image_bw.shape)

      # region props again - Repeat using cucim's regionprops on GPU
      props = regionprops(label_image=labeled, intensity_image=self.image_bw)

      # Extract properties directly into CuPy arrays again
      bboxs = cp.array([prop.bbox for prop in props])
      areas = cp.array([prop.area for prop in props])
      cordinates = cp.array([prop.centroid for prop in props])
      eccentricities = cp.array([prop.eccentricity for prop in props])
      intensity = cp.array([prop.intensity_image.mean() for prop in props])

      if n_samples is not None:
          ind = cp.argsort(intensity)[-n_samples:]
          props = [props[i] for i in cp.asnumpy(ind)]
          bboxs = bboxs[ind]
          areas = areas[ind]
          cordinates = cordinates[ind]
          eccentricities = eccentricities[ind]

      # sort by coordinate y
      idx = cp.argsort(cordinates[:, 0])

      # Store the sorted properties
      self._props = [props[i] for i in cp.asnumpy(idx)]
      self.props["bboxs"] = bboxs[idx].get()
      self.props["areas"] = areas[idx].get()
      self.props["cordinates"] = cordinates[idx].get()
      self.props["eccentricities"] = eccentricities[idx].get()
      self.props["names"] = [f"sample_{i}" for i in range(len(self.props["areas"]))]

      if verbose:
          self.plot_detected_area()

    def crop_samples(self, shrinkage_ratio=0.9):
        self.sample_image_bw = [cp.asnumpy(crop_circle(prop.intensity_image, shrinkage_ratio)) for prop in self._props]
        self.sample_image_inversed_bw = [cp.asnumpy(crop_circle(invert_image(prop.intensity_image), shrinkage_ratio)) for prop in self._props]
        self.sample_image_for_quantification = self.sample_image_inversed_bw.copy()

    def adjust_contrast(self, verbose=True, reset_image=False):
        if reset_image:
            self.sample_image_for_quantification = self.sample_image_inversed_bw.copy()

        for i, image in enumerate(self.sample_image_for_quantification):
            # Adjust contrast using cucim's adjust_log on the GPU
            result = exposure.adjust_log(image, gain=1)
            self.sample_image_for_quantification[i] = result

    def subtract_background(self, sigma=1, verbose=True, reset_image=True):
        if reset_image:
            self.sample_image_for_quantification = self.sample_image_inversed_bw.copy()

        for i, image in enumerate(self.sample_image_for_quantification):
            result = background_subtraction(image=image, sigma=sigma, verbose=False)
            result = result - result[0, 0]
            result[result < 0] = 0
            self.sample_image_for_quantification[i] = result

    # Plot_detected_colonies with cell counts code:
    def plot_detected_colonies(self, plate_name, set_name, day, plot="final", col_num=3, vmax=None, save_path=None, overlay_circle=True, highlight_color="red"):
        image_list = self.sample_image_bw

        if vmax is None:
            vmax = _get_vmax(image_list)

        idx = 1

        for i, image in enumerate(image_list):
            k = (i % col_num + 1)
            ax = plt.subplot(1, col_num, k)
            blobs = self.detected_blobs[i]

            if plot == "raw":
                plt.imshow(cp.asnumpy(image), cmap="gray", vmin=0, vmax=vmax)
                if overlay_circle:
                    plot_circles(circle_list=blobs, ax=ax, args={"color": highlight_color, "alpha": 1})

            name = self.props["names"][i]
            cell_count = len(blobs)
            plt.title(f"{name}: {len(blobs)} colonies")
            
             # Save the image instead of showing it
            if save_path is not None:
                filename = f"{plate_name}_{set_name}_{day}.png"
                full_save_path = os.path.join(save_path, filename)
                plt.savefig(full_save_path)
                print(f"Image saved at {full_save_path}")
            plt.clf()
        
        return cell_count


    # Optimized code - 2:
    # def plot_detected_colonies(self, plot="final", vmax=None, save=None, overlay_circle=True, highlight_color="red"):
    #     image = self.sample_image_bw[0]  # Assuming only 1 image is used

    #     if vmax is None:
    #         vmax = _get_vmax(image)
    #         print("vmax: ", vmax)

    #     fig, ax = plt.subplots()  # Single axis
    #     blobs = self.detected_blobs[0]

    #     if plot == "raw":
    #         plt.imshow(cp.asnumpy(image), cmap="gray", vmin=0, vmax=vmax)
    #         if overlay_circle:
    #             plot_circles(circle_list=blobs, ax=ax, args={"color": highlight_color, "alpha": 1})

    #     name = self.props["names"][0]
    #     plt.title(f"{name}: {len(blobs)} colonies")

    #     plt.show()  # Display the image

    def detect_colonies(self, min_size=5, max_size=15, threshold=0.02, num_sigma=10, overlap=0.5, verbose = True):
      self.detected_blobs = []
      for image in self.sample_image_for_quantification:
          blobs = search_for_blobs(image=cp.asarray(image), min_size=min_size, max_size=max_size, num_sigma=num_sigma, overlap=overlap, threshold=threshold)
          self.detected_blobs.append(blobs)

# Load parameters from the config file
def load_config(config_path='config.json'):
    with open(config_path, 'r') as f:
        config = json.load(f)
    return config['params_by_day']

# Load parameters from the config file
params_by_day = load_config()

def get_day_from_filename(filename):
    """Extract the day from the filename."""
    match = re.search(r'(D7|D14)', filename)
    if match:
        day_number = match.group(1)
        if day_number == 'D7':
            return 'Day7'
        elif day_number == 'D14':
            return 'Day14'
    raise ValueError(f"Unknown day in filename: {filename}")

def process_image(counter, params):
    """Processes an image using the provided counter object and image parameters."""
    
    # Start time for processing the image:
    start_time = time.time()

    path, shrinkage_ratio, radius, min_size, max_size, threshold = params
    set_name = os.path.basename(path).split('_')[0]
    day = get_day_from_filename(os.path.basename(path))   # Extracting the set name from the filename
    counter.load_from_path(path, verbose=False)
    counter.detect_area_by_canny(n_samples=None, radius=radius, n_peaks=1, verbose=False)
    counter.crop_samples(shrinkage_ratio=shrinkage_ratio)
    counter.subtract_background()
    counter.adjust_contrast()
    counter.detect_colonies(min_size=min_size, max_size=max_size, threshold=threshold, verbose=False)

    # End time for processing and calculating the time taken:
    end_time = time.time()
    time_taken = end_time - start_time
    return counter, time_taken, set_name, day


def process_plate(image_files, plate_name, output_folder):
    """Processes a single plate and returns cell counts and execution time."""

    plate_name = plate_name
    plate_data = []

    # For each image, determine the day and apply the respective parameters
    for img_path in image_files:
        day = get_day_from_filename(img_path)
        params = params_by_day[day]  # Get the parameters for the respective day
        plate_data.append((img_path, *params))

    # Create list of Counter objects:
    counters = [Counter() for _ in plate_data]

    # To store the counters and their respective times:
    results = []

    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(process_image, counter, params)
                    for counter, params in zip(counters, plate_data)]

        for future in futures:
            result = future.result()  # result is (counter, time_taken, set_name)
            results.append(result)

    # Plot the detected colonies and get cell count for each image
    cell_count_list = []
    time_taken_list = []
    set_name_list = []

    for counter, time_taken, set_name, day in results:
        cell_count = counter.plot_detected_colonies(set_name = set_name, plate_name = plate_name, day = day, plot='raw', col_num=1, save_path = output_folder)
        cell_count_list.append(cell_count)
        time_taken_list.append(time_taken)
        set_name_list.append(set_name)

    # Create DataFrame for the current plate
    df_plate = pd.DataFrame({
        'Plate': [plate_name] * len(plate_data),
        'Set': set_name_list,
        'Days': [get_day_from_filename(os.path.basename(p[0])) for p in plate_data],
        'Cell Count': cell_count_list,
        'Time Taken (s)': time_taken_list
    })

    return df_plate