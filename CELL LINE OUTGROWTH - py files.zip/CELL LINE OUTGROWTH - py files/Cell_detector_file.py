from Counter_class_methods import process_image, get_day_from_filename, process_plate
import time
import glob
import os
import pandas as pd
import warnings

def main():
    """Processes multiple plates from multiple folders and combines the results."""
    start = time.time()

    # Base directory where plate folders are located
    base_dir = "/content/"
    output_folder = "/content/output_cell_images/"  

    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Find all plate directories (e.g., 'Plate 1', 'Plate 2', etc.)
    plate_dirs = [d for d in glob.glob(os.path.join(base_dir, "Plate *")) if os.path.isdir(d)]
    
    all_data = []

    for plate_dir in plate_dirs:
        # Get the plate name from the folder name
        plate_name = os.path.basename(plate_dir)

        # Find all .tif files in the current plate directory
        image_files = glob.glob(os.path.join(plate_dir, "*.tif"))

        # Filter to keep only Day 7 and Day 14 images
        image_files = [img for img in image_files if 'D7' in img or 'D14' in img] 

        if not image_files:
          print(f"No valid images found for {plate_name}. Skipping this plate.") 
          continue
        else:
          print(f"Processing {plate_name} with {len(image_files)} images...")

        # Process the current plate
        df_plate = process_plate(image_files, plate_name, output_folder)
        all_data.append(df_plate)

    # Concatenate all DataFrames
    df_combined = pd.concat(all_data, ignore_index=True)
    print(df_combined)

    # Save the DataFrame to a CSV file
    df_combined.to_csv('cell_counts_Day7_Day14.csv', index=False)

    end = time.time()
    print(f"Total time taken: {end - start:.2f} seconds")

if __name__ == "__main__":
    main()